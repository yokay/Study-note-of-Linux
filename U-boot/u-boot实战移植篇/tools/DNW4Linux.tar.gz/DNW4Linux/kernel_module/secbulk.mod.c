#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0x1a197155, "struct_module" },
	{ 0xc6183807, "mutex_trylock" },
	{ 0x470b36e4, "usb_find_interface" },
	{ 0x8c667e2, "usb_deregister_dev" },
	{ 0xef440511, "usb_register_driver" },
	{ 0x86cb9d9f, "__mutex_init" },
	{ 0x5d03ae11, "usb_get_dev" },
	{ 0xfbeafc35, "usb_register_dev" },
	{ 0xb85ab97a, "kmem_cache_zalloc" },
	{ 0xab978df6, "malloc_sizes" },
	{ 0xc38ebbf2, "usb_bulk_msg" },
	{ 0xf2a644fb, "copy_from_user" },
	{ 0xdf2126f8, "mutex_unlock" },
	{ 0x37a0cba, "kfree" },
	{ 0x1b7d4074, "printk" },
	{ 0x48ea01b4, "usb_deregister" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "75AD4FBBA22CFEBE590D43D");
