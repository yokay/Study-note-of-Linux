/*
 * (C) Copyright 2002
 * John W. Linville, linville@tuxdriver.com
 *
 * Modified from code for support of MIP405 and PIP405 boards.  Previous
 * copyright follows.
 *
 * (C) Copyright 2001
 * Denis Peter, MPL AG Switzerland, d.peter@mpl.ch
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 *
 */

#ifndef _KBD_H_
#define _KBD_H_

extern int kbd_testc(void);
extern int kbd_getc(void);
extern void kbd_interrupt(void);
extern char *kbd_initialize(void);

unsigned char kbd_is_init(void);
#define KBD_INTERRUPT 1
#endif
